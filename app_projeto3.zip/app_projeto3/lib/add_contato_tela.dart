import 'package:flutter/material.dart';
import 'db.dart';

class AddContactScreen extends StatefulWidget {
  @override
  _AddContactScreenState createState() => _AddContactScreenState();
}

class _AddContactScreenState extends State<AddContactScreen> {
  final DB db = DB();
  final TextEditingController nomeController = TextEditingController();
  final TextEditingController telefoneController = TextEditingController();

  _addContato() async {
    if (nomeController.text.isNotEmpty && telefoneController.text.isNotEmpty) {
      final contato = Contato(
        nome: nomeController.text,
        telefone: telefoneController.text,
      );
      await db.addContato(contato);
      nomeController.clear();
      telefoneController.clear();
      Navigator.pop(context); // Volta para a tela anterior
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Adicionar Contato"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: nomeController,
              decoration: InputDecoration(labelText: "Nome"),
            ),
            TextField(
              controller: telefoneController,
              decoration: InputDecoration(labelText: "Telefone"),
              keyboardType: TextInputType.phone,
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _addContato,
              child: Text("Adicionar"),
            ),
          ],
        ),
      ),
    );
  }
}
