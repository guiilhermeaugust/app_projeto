import 'package:flutter/material.dart';
import 'db.dart';

class EditContactScreen extends StatefulWidget {
  final Contato contato;

  EditContactScreen({required this.contato});

  @override
  _EditContactScreenState createState() => _EditContactScreenState();
}

class _EditContactScreenState extends State<EditContactScreen> {
  final DB db = DB();
  late TextEditingController nomeController;
  late TextEditingController telefoneController;

  @override
  void initState() {
    super.initState();
    nomeController = TextEditingController(text: widget.contato.nome);
    telefoneController = TextEditingController(text: widget.contato.telefone);
  }

  _updateContato() async {
    if (nomeController.text.isNotEmpty && telefoneController.text.isNotEmpty) {
      final contato = Contato(
        id: widget.contato.id,
        nome: nomeController.text,
        telefone: telefoneController.text,
      );
      await db.updateContato(contato);
      Navigator.pop(context); // Volta para a tela anterior
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Editar Contato"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: nomeController,
              decoration: InputDecoration(labelText: "Nome"),
            ),
            TextField(
              controller: telefoneController,
              decoration: InputDecoration(labelText: "Telefone"),
              keyboardType: TextInputType.phone,
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _updateContato,
              child: Text("Atualizar"),
            ),
          ],
        ),
      ),
    );
  }
}
