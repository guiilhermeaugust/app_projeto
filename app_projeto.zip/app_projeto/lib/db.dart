import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class Contato {
  final int? id;
  final String nome;
  final String telefone;

  Contato({this.id, required this.nome, required this.telefone});

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'nome': nome,
      'telefone': telefone,
    };
  }

  factory Contato.fromMap(Map<String, dynamic> map) {
    return Contato(
      id: map['id'],
      nome: map['nome'],
      telefone: map['telefone'],
    );
  }
}

class DB {
  static Database? _database;

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDB();
    return _database!;
  }

  _initDB() async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, 'agenda_contatos.db');
    return await openDatabase(path, version: 1, onCreate: (db, version) async {
      await db.execute('''
        CREATE TABLE contatos(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          nome TEXT,
          telefone TEXT
        )
      ''');
    });
  }

  Future<int> addContato(Contato contato) async {
    final db = await database;
    return await db.insert('contatos', contato.toMap());
  }

  Future<List<Contato>> getContatos() async {
    final db = await database;
    final List<Map<String, dynamic>> maps = await db.query('contatos');
    return List.generate(maps.length, (i) {
      return Contato.fromMap(maps[i]);
    });
  }

  Future<int> updateContato(Contato contato) async {
    final db = await database;
    return await db.update(
      'contatos',
      contato.toMap(),
      where: 'id = ?',
      whereArgs: [contato.id],
    );
  }

  Future<int> deleteContato(int id) async {
    final db = await database;
    return await db.delete(
      'contatos',
      where: 'id = ?',
      whereArgs: [id],
    );
  }
}
