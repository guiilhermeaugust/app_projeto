import 'package:flutter/material.dart';
import 'db.dart';

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final DB db = DB();
  final TextEditingController nomeController = TextEditingController();
  final TextEditingController telefoneController = TextEditingController();
  List<Contato> contatos = [];

  @override
  void initState() {
    super.initState();
    _loadContatos();
  }

  _loadContatos() async {
    contatos = await db.getContatos();
    setState(() {});
  }

  _addContato() async {
    if (nomeController.text.isNotEmpty && telefoneController.text.isNotEmpty) {
      final contato = Contato(
        nome: nomeController.text,
        telefone: telefoneController.text,
      );
      await db.addContato(contato);
      nomeController.clear();
      telefoneController.clear();
      _loadContatos();
    }
  }

  _updateContato(int id) async {
    final contato = Contato(
      id: id,
      nome: nomeController.text,
      telefone: telefoneController.text,
    );
    await db.updateContato(contato);
    nomeController.clear();
    telefoneController.clear();
    _loadContatos();
  }

  _deleteContato(int id) async {
    await db.deleteContato(id);
    _loadContatos();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Agenda de Contatos"), //TITULO DO APP
        titleTextStyle: TextStyle(color: Colors.white, fontSize: 32, fontWeight: FontWeight.bold),
        backgroundColor: Colors.blueGrey[900],
        elevation: 4.0,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextField(
              controller: nomeController,
              decoration: InputDecoration( //Input nome
                labelText: "Nome",
                labelStyle: TextStyle(fontSize: 18, color: Colors.blueGrey),
                border: OutlineInputBorder(),
                filled: true,
                fillColor: Colors.blueGrey[50],
              ),
              style: TextStyle(fontSize: 20),
            ),
            SizedBox(height: 16),
            TextField(
              controller: telefoneController,
              decoration: InputDecoration( //Input telefone
                labelText: "Telefone",
                labelStyle: TextStyle(fontSize: 18, color: Colors.blueGrey),
                border: OutlineInputBorder(),
                filled: true,
                fillColor: Colors.blueGrey[50],
              ),
              style: TextStyle(fontSize: 20),
              keyboardType: TextInputType.phone,
            ),
            SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                ElevatedButton( //Botão para adicionar um novo contato
                  onPressed: _addContato,
                  style: ElevatedButton.styleFrom(
                    padding: EdgeInsets.symmetric(horizontal: 30, vertical: 12), backgroundColor: Colors.white,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
                    textStyle: TextStyle(fontSize: 18),
                  ),
                  child: Text("Adicionar"),
                ),
                ElevatedButton(
                  onPressed: () {
                    if (nomeController.text.isNotEmpty && telefoneController.text.isNotEmpty) {
                      _updateContato(contatos.first.id!);
                    }
                  },
                  style: ElevatedButton.styleFrom( //Botão para atualizar um contato
                    padding: EdgeInsets.symmetric(horizontal: 30, vertical: 12), backgroundColor: Colors.white,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
                    textStyle: TextStyle(fontSize: 18),
                  ),
                  child: Text("Atualizar"),
                ),
              ],
            ),
            SizedBox(height: 16),
            Expanded(
              child: ListView.builder(
                itemCount: contatos.length,
                itemBuilder: (context, index) {
                  final contato = contatos[index];
                  return Card(
                    margin: EdgeInsets.symmetric(vertical: 8),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    elevation: 4,
                    child: ListTile( //Dados do contato
                      contentPadding: EdgeInsets.symmetric(vertical: 12, horizontal: 16),
                      title: Text(contato.nome, style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                      subtitle: Text(contato.telefone, style: TextStyle(fontSize: 18, color: Colors.grey[600])),
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          IconButton(//Botão Para Editar um contato
                            icon: Icon(Icons.edit, color: Colors.blueGrey),
                            onPressed: () {
                              nomeController.text = contato.nome;
                              telefoneController.text = contato.telefone;
                            },
                          ),
                          IconButton( //Botão Para deletar um contato
                            icon: Icon(Icons.delete, color: Colors.red),
                            onPressed: () => _deleteContato(contato.id!),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
